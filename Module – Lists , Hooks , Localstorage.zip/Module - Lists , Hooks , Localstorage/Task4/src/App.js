import ListView from "./Component/ListView";


function App() {
  return (
    <div className="App">
     <ListView/>
    </div>
  );
}

export default App;
