import Login from "./Component/Login";


function App() {
  return (
    <div className="App">
      <Login/>
    </div>
  );
}

export default App;
