import Counterapp from "./Component/Counterapp";


function App() {
  return (
    <div className="App">
    <Counterapp/>
    </div>
  );
}

export default App;
